<?php

namespace MercadoPago\Client\Payment;

/** PaymentRefundCreateRequest class. */
class PaymentRefundCreateRequest
{
    /** Amount to be refunded. */
    public float $amount;
}
