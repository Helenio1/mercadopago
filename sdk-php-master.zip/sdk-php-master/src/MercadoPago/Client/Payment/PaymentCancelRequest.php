<?php

namespace MercadoPago\Client\Payment;

/** PaymentCancelRequest class. */
class PaymentCancelRequest
{
    /** Status cancelled. */
    public string $status = "cancelled";
}
