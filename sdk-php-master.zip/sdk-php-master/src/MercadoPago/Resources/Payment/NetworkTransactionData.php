<?php

namespace MercadoPago\Resources\Payment;

/** NetworkTransactionData class. */
class NetworkTransactionData
{
    /** Network transaction ID. */
    public ?string $network_transaction_id;
} 