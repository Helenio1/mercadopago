<?php

namespace MercadoPago\Resources\Common;

/** DifferentialPricing class. */
class DifferentialPricing
{
    /** Differential pricing ID. */
    public ?int $id;
}
