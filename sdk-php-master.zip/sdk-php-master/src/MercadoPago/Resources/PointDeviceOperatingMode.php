<?php

namespace MercadoPago\Resources;

use MercadoPago\Net\MPResource;

/** PointDeviceOperatingMode class. */
class PointDeviceOperatingMode extends MPResource
{
    /** Operating mode. */
    public string $operating_mode;
}
